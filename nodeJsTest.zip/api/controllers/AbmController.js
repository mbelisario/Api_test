'use strict';

var mongoose = require('mongoose'),
  Task = mongoose.model('Tasks'),
  Request = mongoose.model('Request'),
  Movement = mongoose.model('Movement');